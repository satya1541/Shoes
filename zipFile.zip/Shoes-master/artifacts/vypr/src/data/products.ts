import shoeVoltRunner from "@assets/generated_images/shoe-volt-runner.png";
import shoeOceanSurge from "@assets/generated_images/shoe-ocean-surge.png";
import shoeHyperice from "@assets/generated_images/shoe-hyperice.png";
import shoeCrimsonGhost from "@assets/generated_images/shoe-crimson-ghost.png";
import shoeMidnightForce from "@assets/generated_images/shoe-midnight-force.png";
import shoeAeroStrike from "@assets/generated_images/shoe-aero-strike.png";
import shoeHyperIceLite from "@assets/generated_images/shoe-hyperice-lite.png";

export interface Product {
  id: string;
  name: string;
  price: string;
  priceNum: number;
  img: string;
  tagline: string;
  description: string;
  colors: string[];
  sizes: number[];
  category: string;
  tag?: string;
}

export const PRODUCTS: Product[] = [
  {
    id: "volt-runner",
    name: "VOLT RUNNER",
    price: "£189",
    priceNum: 189,
    img: shoeVoltRunner,
    tagline: "Born to Break Limits",
    description:
      "Forged in the underground. Engineered for the skyline. The Volt Runner defies gravity and expectations with relentless energy return and unapologetic style. Its dual-layer foam stack delivers explosive propulsion, while the reinforced woven upper locks you in at every stride.",
    colors: ["Electric Yellow", "Midnight Black"],
    sizes: [6, 7, 8, 9, 10, 11, 12],
    category: "Performance",
    tag: "BESTSELLER",
  },
  {
    id: "hyperice-lite",
    name: "HYPERICE LITE",
    price: "£179",
    priceNum: 179,
    img: shoeHyperIceLite,
    tagline: "Cold Precision",
    description:
      "Precision-engineered for the athlete who demands control. The HYPERICE LITE strips away everything unnecessary, leaving only the mechanical advantage. Arctic-white upper. Featherlight frame. Zero compromise.",
    colors: ["Arctic White", "Teal"],
    sizes: [6, 7, 8, 9, 10, 11, 12],
    category: "Lifestyle",
  },
  {
    id: "crimson-ghost",
    name: "CRIMSON GHOST",
    price: "£219",
    priceNum: 219,
    img: shoeCrimsonGhost,
    tagline: "Worn to Win",
    description:
      "A silhouette born from high-fashion editorials and the streets of Milan. The Crimson Ghost commands attention before you move. Deep crimson leather, aggressive stance, and a sole unit tuned for the runway and the ring.",
    colors: ["Blood Crimson", "Carbon Black"],
    sizes: [7, 8, 9, 10, 11, 12],
    category: "Fashion",
    tag: "LIMITED",
  },
  {
    id: "aero-strike",
    name: "AERO STRIKE",
    price: "£199",
    priceNum: 199,
    img: shoeAeroStrike,
    tagline: "Speed in Every Fibre",
    description:
      "The Aero Strike was designed in a wind tunnel and tested on the track. Its streamlined profile cuts through air resistance while the carbon-fibre shank transmits every ounce of force into forward motion.",
    colors: ["Neon Green", "Dark Graphite"],
    sizes: [6, 7, 8, 9, 10, 11, 12],
    category: "Performance",
  },
  {
    id: "midnight-force",
    name: "MIDNIGHT FORCE",
    price: "£169",
    priceNum: 169,
    img: shoeMidnightForce,
    tagline: "Owns the Dark",
    description:
      "All-black. All-everything. The Midnight Force is the shoe you wear when you mean business. Matte upper, silver hardware, and a cushioning system that absorbs impact as silently as it propels you forward.",
    colors: ["Midnight Black", "Silver"],
    sizes: [6, 7, 8, 9, 10, 11, 12],
    category: "Lifestyle",
  },
  {
    id: "ocean-surge",
    name: "OCEAN SURGE",
    price: "£239",
    priceNum: 239,
    img: shoeOceanSurge,
    tagline: "Born of the Deep",
    description:
      "Inspired by the crushing pressure and raw power of the deep ocean. The Ocean Surge features a water-resistant upper treated with a hydrophobic nano-coating, and a sole compound engineered for grip on wet surfaces.",
    colors: ["Deep Navy", "Electric Blue"],
    sizes: [6, 7, 8, 9, 10, 11, 12],
    category: "Performance",
    tag: "NEW",
  },
];

export const CATEGORIES = ["All", "Performance", "Lifestyle", "Fashion"];
